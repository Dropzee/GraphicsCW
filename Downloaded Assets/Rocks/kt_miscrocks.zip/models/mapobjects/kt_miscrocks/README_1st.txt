-------------------------------------------------------------------------

TITLE : kt_miscrocks
AUTHOR : ken 'kat' beyer
EMAIL ADDRESS : info@quake3bits.com
HOMEPAGE URL : http://www.quake3bits.co.uk
NUMBER OF MODELS : 10
SHADER SCRIPTS : n/a

===========================
INFO
Replace the default texture with a sahder or texture more appropriate to the environment the model'd to be placed into.

To do this you need to manually edit the *.ase files in NotePad or similar ammending the files paths where appropriate.
Re-save to a different version to save overwrites and/or confusion.

===========================


* MODEL NAME/s *
[model details below]
rock1.ase
rock2.ase
rock3.ase
rock4.ase
rock5.ase
rock6.ase
rock7.ase
rock8.ase
rock9.ase
rock10.ase


------------------

CREDITS
ID software

NONE COMMERCIAL DISTRIBUTION
as long as this readme is included...!

COMMERCIAL DISTRIBUTION IN *ANY FORM* IS PROHIBITED
For COMMERCIAL and MOD use please contact the author above.

--------------------------------------------------------------------------